<?php
	$PROXY_TYPES = array(
      array(
         'id_proxy_type' => 1,
         'proxy_type' => 'linux',
         'proxy_descr' => 'Proxy Linux Standard',
      ),
      array(
         'id_proxy_type' => 2,
         'proxy_type' => 'windows',
         'proxy_descr' => 'Proxy Windows Standard',
      ),
   );

?>
