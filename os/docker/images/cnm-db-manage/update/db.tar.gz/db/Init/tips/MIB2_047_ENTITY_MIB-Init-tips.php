<?php
      $TIPS[]=array(
         'id_ref' => 'mib2_ent_phy_parts',	'tip_type' => 'cfg',	'url' => '',
         'date' => '',     'tip_class' => 1,	'name' => 'Descripcion',
         'descr' => 'Mide: <strong>chassis-bplane|powerSup|unk-other|fan|cpu|sensor|module|port|container|stack|all</strong> a partir de los siguientes atributos de la mib ENTITY-MIB:<br><br><strong>ENTITY-MIB::entPhysicalClass (GAUGE):</strong> "An indication of the general hardware type of the physical
             entity.
 
             An agent should set this object to the standard enumeration
             value that most accurately indicates the general class of
             the physical entity, or the primary class if there is more
             than one entity.
 
             If no appropriate standard registration identifier exists
             for this physical entity, then the value other(1) is
             returned.  If the value is unknown by this agent, then the
             value unknown(2) is returned."
',
      );


?>
