<?php

   $CFG_APP_PARAM[]=array(
      'aname' => 'app_socups_input_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '04555-SOCOMECUPS_INPUT_TABLE.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_socups_input_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_socups_input_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );



   $CFG_APP_PARAM[]=array(
      'aname' => 'app_socups_output_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '04555-SOCOMECUPS_OUTPUT_TABLE.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_socups_output_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_socups_output_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );


?>
