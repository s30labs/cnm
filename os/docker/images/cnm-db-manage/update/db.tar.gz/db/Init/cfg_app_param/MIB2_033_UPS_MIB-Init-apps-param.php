<?php

   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ups_input_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '00000-33-UPS_INPUT_TABLE.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ups_input_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ups_input_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );



   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ups_output_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '00000-33-UPS_OUTPUT_TABLE.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ups_output_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ups_output_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );


?>
