<?php
      $TIPS[]=array(
         'id_ref' => 'app_poe_psu_usage',  'tip_type' => 'app', 'url' => '',
         'date' => 1430855476,     'tip_class' => 1, 'name' => 'Descripcion',
         'descr' => '<strong>Muestra el consumo de las fuentes de potencia del equipo</strong><br>Utiliza la tabla SNMP POWER-ETHERNET-MIB::pethMainPseTable (Enterprise=00000)<br><br><strong>POWER-ETHERNET-MIB::pethMainPsePower (GAUGE):</strong><br>"The nominal power of the PSE expressed in Watts."
<strong>POWER-ETHERNET-MIB::pethMainPseOperStatus (GAUGE):</strong><br>"The operational status of the main PSE."
<strong>POWER-ETHERNET-MIB::pethMainPseConsumptionPower (GAUGE):</strong><br>"Measured usage power expressed in Watts."
<strong>POWER-ETHERNET-MIB::pethMainPseUsageThreshold (GAUGE):</strong><br>"The usage threshold expressed in percents for
                 comparing the measured power and initiating
                 an alarm if the threshold is exceeded."
<strong>POWER-ETHERNET-MIB::pethNotificationControlEnable (GAUGE):</strong><br>"This object controls, on a per-group basis, whether
              or not notifications from the agent are enabled.  The
              value true(1) means that notifications are enabled; the
              value false(2) means that they are not."
',
      );


?>
