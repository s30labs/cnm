<?php

	$NOTE_TYPES = array(
      array(
         'name' => 'INCIDENCIA HARDWARE',
      ),
      array(
         'name' => 'INCIDENCIA SOFTWARE',
      ),
      array(
         'name' => 'OPERATIVA PROPIA',
      ),
      array(
         'name' => 'OPERATIVA AJENA',
      ),
   );

?>
