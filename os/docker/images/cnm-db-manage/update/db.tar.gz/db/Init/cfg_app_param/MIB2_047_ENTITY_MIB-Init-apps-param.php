<?php

   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ent_phys_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '00000-47-ENTITY_PHYS_TABLE.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ent_phys_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ent_phys_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );



   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ent_logic_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '00000-47-ENTITY_LOGIC_TABLE.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ent_logic_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ent_logic_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );


?>
