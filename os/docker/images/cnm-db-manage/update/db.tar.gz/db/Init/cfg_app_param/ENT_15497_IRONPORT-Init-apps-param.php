<?php

   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ironport_keys', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '15497-IRONPORT-KEYS.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ironport_keys', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ironport_keys', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );



   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ironport_updates', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '15497-IRONPORT-UPDATES.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ironport_updates', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ironport_updates', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );



   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ironport_performance', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '15497_IRONPORT-performance.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ironport_performance', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_ironport_performance', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );


?>
