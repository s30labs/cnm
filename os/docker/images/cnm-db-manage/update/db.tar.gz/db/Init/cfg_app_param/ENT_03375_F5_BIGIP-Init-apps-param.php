<?php

   $CFG_APP_PARAM[]=array(
      'aname' => 'app_f5bigip_pool_info', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '03375_F5BIGIP_POOL_INFO.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_f5bigip_pool_info', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_f5bigip_pool_info', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );


?>
