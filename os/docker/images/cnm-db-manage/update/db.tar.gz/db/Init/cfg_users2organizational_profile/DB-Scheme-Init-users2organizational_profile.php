<?php
$CFG_USERS2ORGANIZATIONAL_PROFILE = array(
      array(
         'id_user' => '1',
         'id_cfg_op' => '1',
         'login_name' => 'admin',
      ),
);
?>
