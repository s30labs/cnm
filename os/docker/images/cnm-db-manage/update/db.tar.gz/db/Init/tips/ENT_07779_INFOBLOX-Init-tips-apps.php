<?php
      $TIPS[]=array(
         'id_ref' => 'app_infoblox_get_info',  'tip_type' => 'app', 'url' => '',
         'date' => 1430853213,     'tip_class' => 1, 'name' => 'Descripcion',
         'descr' => '<strong>Muestra informacion basica sobre el equipo</strong><br>Utiliza atributos de la mib IB-PLATFORMONE-MIB:<br><br><strong>IB-PLATFORMONE-MIB::ibHardwareType (GAUGE):</strong>&nbsp;"Infoblox One hardware type"
<br><strong>IB-PLATFORMONE-MIB::ibSerialNumber (GAUGE):</strong>&nbsp;"Infoblox One device serial number"
<br><strong>IB-PLATFORMONE-MIB::ibNiosVersion (GAUGE):</strong>&nbsp;"Infoblox One NIOS version"
<br>',
      );


?>
