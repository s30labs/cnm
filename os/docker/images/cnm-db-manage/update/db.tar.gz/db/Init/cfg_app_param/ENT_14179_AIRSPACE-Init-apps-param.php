<?php

   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_apifinfo_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '14179-AIRSPACE-APIFINFO-MIB.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_apifinfo_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_apifinfo_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );



   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_apinfo_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '14179-AIRSPACE-APINFO-MIB.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_apinfo_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_apinfo_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );



   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_apload_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '14179-AIRSPACE-APLOAD-MIB.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_apload_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_apload_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );



   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_approfiles_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '14179-AIRSPACE-APPROFILE-MIB.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_approfiles_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_approfiles_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );



   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_mobinfo_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '14179-AIRSPACE-MOBINFO-MIB.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_mobinfo_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_mobinfo_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );



   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_rogueinfo_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '14179-AIRSPACE-ROGUEINFO-MIB.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_rogueinfo_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_airspace_rogueinfo_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );


?>
