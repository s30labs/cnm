<?php

   $CFG_APP_PARAM[]=array(
      'aname' => 'app_compaq_power_supply_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '00232-COMPAQ-MIB_CPQHLTH_POWER_SUPPLY_TABLE.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_compaq_power_supply_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_compaq_power_supply_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );



   $CFG_APP_PARAM[]=array(
      'aname' => 'app_compaq_processes_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '00232-COMPAQ-MIB_CPQOS_PROCESS_TABLE.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_compaq_processes_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_compaq_processes_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );



   $CFG_APP_PARAM[]=array(
      'aname' => 'app_compaq_pci_table', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '00232-COMPAQ-MIB_CPQSTDEQ_PCI_TABLE.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_compaq_pci_table', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_compaq_pci_table', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );


?>
