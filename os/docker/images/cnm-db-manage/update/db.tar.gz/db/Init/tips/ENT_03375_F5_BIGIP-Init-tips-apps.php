<?php
      $TIPS[]=array(
         'id_ref' => 'app_f5bigip_pool_info',  'tip_type' => 'app', 'url' => '',
         'date' => 1430852789,     'tip_class' => 1, 'name' => 'Descripcion',
         'descr' => '<strong>Muestra informacion relevante sobre los pools definidos en el equipo</strong><br>Utiliza la tabla SNMP F5-BIGIP-LOCAL-MIB::ltmPoolTable (Enterprise=03375)<br><br><strong>F5-BIGIP-LOCAL-MIB::ltmPoolName (GAUGE):</strong><br>"The name of a pool."
<strong>F5-BIGIP-LOCAL-MIB::ltmPoolLbMode (GAUGE):</strong><br>"The load balance method for this pool"
<strong>F5-BIGIP-LOCAL-MIB::ltmPoolActiveMemberCnt (GAUGE):</strong><br>"The number of the current active members in the specified pool."
<strong>F5-BIGIP-LOCAL-MIB::ltmPoolMonitorRule (GAUGE):</strong><br>"The name of monitor rule used by the specified pool."
<strong>F5-BIGIP-LOCAL-MIB::ltmPoolMemberCnt (GAUGE):</strong><br>"The total number of members in the specified pool."
<strong>F5-BIGIP-LOCAL-MIB::ltmPoolEnabledState (GAUGE):</strong><br>"Deprecated!  
 		Replaced by ltmPoolStatusEnabledState under ltmPoolStatus.
 		The state of the specified pool activity status, as specified by the user."
',
      );


?>
