<?php

   $CFG_APP_PARAM[]=array(
      'aname' => 'app_raid_sview_phys_dev', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '00231-RAID_SERVERVIEW-PHYS-DEV.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_raid_sview_phys_dev', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_raid_sview_phys_dev', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );


?>
