<?php
      $TIPS[]=array(
         'id_ref' => '',  'tip_type' => 'app', 'url' => '',
         'date' => 1373906972,     'tip_class' => 1, 'name' => 'Descripcion',
         'descr' => '<strong></strong><br>Utiliza atributos de la mib :<br><br>',
      );


?>
