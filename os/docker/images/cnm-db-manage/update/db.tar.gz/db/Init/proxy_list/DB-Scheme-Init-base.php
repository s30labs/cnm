<?php
	$PROXY_LIST[] = array(
      'id_proxy' => '1',
      'proxy_host' => 'localhost',
      'proxy_port' => '22',
      'proxy_type' => 'linux',
      'proxy_user' => 'root',
      'proxy_pwd' => '',
      'proxy_passphrase' => '',
      'proxy_key_path' => '',
      'proxy_options' => '',
      'proxy_exec_prefix' => '',
   );
?>
