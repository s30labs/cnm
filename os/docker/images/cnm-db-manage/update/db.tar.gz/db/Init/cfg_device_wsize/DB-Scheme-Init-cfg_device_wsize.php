<?php

$CFG_DEVICE_WSIZE[]=array(
	'wsize'=>0,
	'label'=>'Normal'
);

?>
