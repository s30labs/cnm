<?php
      $TIPS[]=array(
         'id_ref' => 'app_juniper_get_info',  'tip_type' => 'app', 'url' => '',
         'date' => 1430853594,     'tip_class' => 1, 'name' => 'Descripcion',
         'descr' => '<strong>Muestra informacion basica sobre el equipo</strong><br>Utiliza atributos de la mib JUNIPER-IVE-MIB:<br><br><strong>JUNIPER-IVE-MIB::productName (GAUGE):</strong>&nbsp;"IVE Licensed Product Name"
<br><strong>JUNIPER-IVE-MIB::productVersion (GAUGE):</strong>&nbsp;"IVE System Software Version"
<br>',
      );


?>
