<?php

   $CFG_APP_PARAM[]=array(
      'aname' => 'app_asterisk_chan_type', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '22736-ASTERISK-CHANNEL-TYPES.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_asterisk_chan_type', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_asterisk_chan_type', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );



   $CFG_APP_PARAM[]=array(
      'aname' => 'app_asterisk_get_info', 'hparam' => '20000008', 'type' => 'snmp', 'enable' => '1', 'value' => '22736_ASTERISK-get_info.xml',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_asterisk_get_info', 'hparam' => '20000009', 'type' => 'snmp', 'enable' => '1', 'value' => 'json',
      'script' => 'snmptable',
   );
   $CFG_APP_PARAM[]=array(
      'aname' => 'app_asterisk_get_info', 'hparam' => '2000000a', 'type' => 'snmp', 'enable' => '1', 'value' => '',
      'script' => 'snmptable',
   );


?>
