<?php
	$CFG_TASK_CONFIGURED[]=array();

/*
      $CFG_TASK_CONFIGURED[]=array(
				'name'=>'BACKUP DE CNM', 'descr'=>'', 'frec'=>'D',
				'cron'=>'00 04 * * * *', 'task'=>'app_cnm_backup',
				'done'=>'0', 'exec'=>'0', 'atype'=>'12',
				'subtype'=>'app_cnm_backup-c810d259', 'params'=>'',
      );
*/
?>
