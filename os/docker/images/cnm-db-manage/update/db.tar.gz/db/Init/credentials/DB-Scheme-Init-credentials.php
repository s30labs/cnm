<?php
$CREDENTIALS = array(
   array(
		'name'   => 'local2',
		'descr'  => 'local2',
		'type'   => 'syslog-local2',
		'user'   => '',
		'pwd'    => '',
		'scheme' => 'local2',
		'port'   => '0',
   ),
   array(
      'name'   => 'local3',
      'descr'  => 'local3',
      'type'   => 'syslog-local3',
      'user'   => '',
      'pwd'    => '',
      'scheme' => 'local3',
      'port'   => '0',
   ),
   array(
      'name'   => 'local4',
      'descr'  => 'local4',
      'type'   => 'syslog-local4',
      'user'   => '',
      'pwd'    => '',
      'scheme' => 'local4',
      'port'   => '0',
   ),
   array(
      'name'   => 'filters',
      'descr'  => 'filters',
      'type'   => 'syslog-filters',
      'user'   => '',
      'pwd'    => '',
      'scheme' => 'filters',
      'port'   => '0',
   ),
	array(
      'name'   => 'Default API',
      'descr'  => 'Default Credentials',
      'type'   => 'api',
      'user'   => 'admin',
      'pwd'    => 'cnm123',
      'scheme' => '',
      'port'   => '0',
   ),

);
?>
